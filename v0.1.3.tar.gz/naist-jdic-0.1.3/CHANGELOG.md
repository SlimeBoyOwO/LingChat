# ChangeLog

## Before v0.1.0

The files were copied from OpenJTalk to jpreprocess,
and then from jpreprocess to this repository.

While the files were in jpreprocess, some words were modified.

* [Broken accent rules were fixed](https://github.com/jpreprocess/jpreprocess/commit/abadf7c1a2745e2de49c0ee760c3734ada41d820#diff-59216a03e32b0f71cc9bd619896bd04e153c46db349b913001d219c8734816e4)
  
  ```diff
  - 名詞%F2@1/形容詞%F2@-1動詞%F2@0
  + 名詞%F2@1/形容詞%F2@-1/動詞%F2@0
  ```

## v0.1.0

Initial Release. Nothing was changed.

## v0.1.1

* Add documentation by @femshima in <https://github.com/jpreprocess/naist-jdic/pull/3>
* fix カ往促音便 by @femshima in <https://github.com/jpreprocess/naist-jdic/pull/4>

## v0.1.2

* Apply NEologd patch on pronunciations by @femshima in <https://github.com/jpreprocess/naist-jdic/pull/5>
* Remove numbers from unidic by @femshima in <https://github.com/jpreprocess/naist-jdic/pull/6>

## v0.1.3

* Fix mora size by @femshima in <https://github.com/jpreprocess/naist-jdic/pull/7>
